# Tasks

- ssh-key ---> first-key
- assign first-key to newly created instance .
- create a security group
- assign that group to instance .

- nginx install
- /var/www/html/index.nginx-debian.html -> hey , Nilay